//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"
#import <bestcycling_webview/BestcyclingWebviewPlugin.h>

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [BestcyclingWebviewPlugin registerWithRegistrar:[registry registrarForPlugin:@"BestcyclingWebviewPlugin"]];
}

@end
